public class BST<V> {

    public BST(int key, V value) {

    }

    public void insert(int k, V v) {
        return;
    }

    public V find(int k) {
        return null;
    }

    public int findMin() {
        return 0;
    }

    public void removeMin() {
        return;
    }

    public void remove(int k) {
        return;
    }

    void print(){
        return;
    }

    int predecessor(int k) {
        return 0;
    }

}
