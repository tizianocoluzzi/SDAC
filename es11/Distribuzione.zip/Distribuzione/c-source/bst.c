#include <stdlib.h>
#include <stdio.h>
#include "bst.h"

bst * bst_new(int k, void * v) {
	return NULL;
}

void bst_insert(bst * b, int k, void * v) {
	return;
}

void * bst_find(bst * b, int k) {
	return NULL;
}

int bst_find_min(bst * b) {
	return 0;
}

void bst_remove_min(bst * b) {
	return;
}

void bst_remove(bst * b, int k) {
	return;
}

void bst_delete(bst * b) {
	return;
}

void bst_print(bst * b){
	return;
}

int bst_predecessor(bst * b, int k) {
    return 0;
}