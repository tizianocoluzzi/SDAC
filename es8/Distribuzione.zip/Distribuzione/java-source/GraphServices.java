public class GraphServices<V> {

    public static <V> void sweep(Graph<V> g) {

    }
    
    public static <V> void topologicalSort(Graph<V> g) {

    }
    
    public static <V> void strongConnectedComponents(Graph<V> g) {
        
    }
}
