/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
/**
 *
 * @author silvia
 */
public class Algoritmi {
    
     
    public static void permuta_negativi_positivi(float [] a){
        System.out.println("Metodo non ancora implementato... Risultato non disponibile");
        return;
}
    
    public static void bandiera(char[] a){
        System.out.println("Metodo non ancora implementato... Risultato non disponibile");
        return;
    }
    
       
    public static boolean isQuadratoLatino(int[][] m){
        System.out.println("Metodo non ancora implementato... Risultato non disponibile");
        return false;
    }
    
        
    public static void primiKMin(float[] a, int k){
        System.out.println("Metodo non ancora implementato... Risultato non disponibile");
        return;
    }
    
}
