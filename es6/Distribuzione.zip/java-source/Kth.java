public class Kth {

    public Kth(int k) {}

    public void insert(int key) {
        return;
    }

    public int get() {
        return 0;
    }

    public void remove() {
        return;
    }

}
