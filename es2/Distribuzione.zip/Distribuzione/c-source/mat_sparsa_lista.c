#include "mat_sparsa_lista.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct elem {

} elem;

struct matrice_sparsa {

};

matrice_sparsa* matrice_sparsa_new(int m, int n) {
	// TODO: Implement here
	return NULL;
}

void matrice_sparsa_delete(matrice_sparsa* mat) {
	// TODO: Implement here
}

int get_num_row(matrice_sparsa* mat) {
	// TODO: Implement here
	return 0;
}

int get_num_col(matrice_sparsa* mat) {
	// TODO: Implement here
	return 0;
}

void mat_set(matrice_sparsa* mat, int i, int j, int x) {
	// TODO: Implement here
}

int mat_get(matrice_sparsa* mat, int i, int j) {
	// TODO: Implement here
	return 0;
}

void mat_print(matrice_sparsa* mat) {
	// TODO: Implement here
}
